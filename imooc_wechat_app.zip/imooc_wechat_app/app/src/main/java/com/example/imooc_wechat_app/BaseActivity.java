package com.example.imooc_wechat_app;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class BaseActivity extends AppCompatActivity implements View.OnClickListener {

    private Button btnDemo,btnWebChat,btnBanner,btnSplash;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base);
        initView();
    }

    private void initView(){
        btnDemo = findViewById(R.id.btnWeb);
        btnWebChat = findViewById(R.id.btnUpgradeWeb);
        btnBanner = findViewById(R.id.btnBanner);
        btnSplash = findViewById(R.id.btnSplash);
        btnDemo.setOnClickListener(this);
        btnBanner.setOnClickListener(this);
        btnWebChat.setOnClickListener(this);
        btnSplash.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btnWeb:
                Intent intent = new Intent(BaseActivity.this,MainActivity.class);
                startActivity(intent);
                break;
            case R.id.btnUpgradeWeb:
                Intent intent1 = new Intent(BaseActivity.this,MainActivityTab.class);
                startActivity(intent1);
                break;
            case R.id.btnBanner:
                Intent intent2 = new Intent(BaseActivity.this,BannerActivity.class);
                startActivity(intent2);
                break;
            case R.id.btnSplash:
                Intent intent3 = new Intent(BaseActivity.this,SplashActivity.class);
                startActivity(intent3);
                break;

        }
    }
}
